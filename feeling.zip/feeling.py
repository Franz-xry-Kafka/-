import csv
from textblob import TextBlob
import nltk
import numpy as np

nltk.download('averaged_perceptron_tagger')
nltk.download('punkt')
nltk.download('brown')
nltk.download('wordnet')

with open ('D:/2020秋季学期/机器学习/情感判断/train.csv','r') as f:
        reader = csv.reader(f)
        #result = list(reader)
        for row in reader:
            blob = TextBlob(row[1])
            print (blob.tags)

for sentence in blob.sentences:
    str(sentence.sentiment.polarity)


    def vectorize_sequences(sequences, dimension=10000):
        results = np.zeros((len(sequences), dimension))
        for i, sequence in enumerate(sequences):
            results[i, sequence] = 1  # one-hot
        return results


    x_train = vectorize_sequences(train_data)
    x_test = vectorize_sequences(test_data)

    y_train = np.asarray(train_labels).astype('float32')
    y_test = np.asarray(test_labels).astype('float32')

    model = models.Sequential()

    model.add(layers.Dense(16, activation='relu', input_shape=(10000,)))
    model.add(layers.Dense(16, activation='relu'))
    model.add(layers.Dense(1, activation='sigmoid'))

    model.compile(optimizer='rmsprop', loss='binary_crossentropy', metrics=['accuracy'])

    model.fit(x_train, y_train, epochs=4, batch_size=512)
    results = model.evaluate(x_test, y_test)
'''
        for i in range(400):
            blob = TextBlob(result[i][2])
for sentence in blob.sentences:
    print(str(sentence.sentiment.polarity))'''